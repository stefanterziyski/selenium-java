package task;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetHomePage {
	//WebDriver configurations
	private static final String RELATIVE_DRIVER_PATH = "lib/chromedriver";
	private static final String CHROME_SYSTEM_PROPERTY = "webdriver.chrome.driver";
	private static final int SECONDS_TO_WAIT = 5;
	
	//Google Search
	private static final String GOOGLE_URL = "http://www.google.com";
	private static final String SEARCH_BOX_ID = "lst-ib";
	private static final String AUDI_SEARCH_STRING = "Audi";
	
	//Find Audi HomePage in Search results
	private static final String CONTAINER_CLASS = "rc";
	private static final String LINK_TAG_NAME = "a";
	private static final String LINK_ATTRIBUTE_NAME = "href";
	private static final String HOME_PAGE_IDENTIFIER = "www.audi.com";
	
	//Error message
	private static final String HOME_PAGE_LINK_ERROR = "The link to the Audi Home Page was not found";
	

	public static void main(String[] args) {
		setUp();
		//1. open www.google.com
		WebDriver chromeBrowser = openGoogle();
		//2. search for 'Audi' and get result list
		List<WebElement> resultList = searchForAudi(chromeBrowser);
		//3. find and open the Audi Home Page in Chrome
		openAudiHomePage(resultList);
	}
	
	public static void setUp(){
		File driverFile = new File(RELATIVE_DRIVER_PATH);
		driverFile.setReadable(true);
		driverFile.setExecutable(true);
		System.setProperty(CHROME_SYSTEM_PROPERTY, driverFile.getAbsolutePath());
	}

	private static WebDriver openGoogle() {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(SECONDS_TO_WAIT, TimeUnit.SECONDS);
		driver.navigate().to(GOOGLE_URL);
		return driver;
	}

	private static List<WebElement> searchForAudi(WebDriver driver) {
		WebElement searchBar = driver.findElement(By.id(SEARCH_BOX_ID));
		searchBar.sendKeys(AUDI_SEARCH_STRING);
		searchBar.sendKeys(Keys.ENTER);
		return driver.findElements(By.className(CONTAINER_CLASS));
	}
	
	private static void openAudiHomePage(List<WebElement> containers) {
		WebElement linkToAudiHomePage = findLinkToHomePage(containers);
		if(linkToAudiHomePage != null){
			linkToAudiHomePage.click();
		} 
		else {
			System.out.println(HOME_PAGE_LINK_ERROR);
		}
	}

	private static WebElement findLinkToHomePage(List<WebElement> containers) {
		WebElement result = null;
		for(WebElement container : containers){
			WebElement linkElement = container.findElement(By.tagName(LINK_TAG_NAME));
			String url = linkElement.getAttribute(LINK_ATTRIBUTE_NAME);
			if(url.contains(HOME_PAGE_IDENTIFIER)){
				result = linkElement;
				break;
			}
		}
		return result;
	}
}