Програмата се намира в SeleniumJavaTask, където 
в SeleniumJavaTask/src се намира task.GetHomePage.java - самият код
в SeleniumJavaTask/bin се намира task.GetHomePage.class
в SeleniumJavaTask/lib се намират всички *.jar файлове на Sellenium и
chromedriver което е драйвъра за Chrome
=====================================
Програмата е писана за Linux/Ubuntu със Chrome

За да работи на Windows е необходим chromedriver.exe файл, който не е
включен в този проект и съответно да се променят следните настройки в самия код:

	private static final String RELATIVE_DRIVER_PATH = "lib/chromedriver";

трябва да се измени стойноста за новия файл на Windows

	private static final String RELATIVE_DRIVER_PATH = "lib/chromedriver.exe";
======================================
Това е Eclipse  проект, който може да се  import-ира в нов Java Project.
======================================
